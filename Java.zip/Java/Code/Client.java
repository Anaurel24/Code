public class Client { 
    private int nci;
    private String nomComplet;
    private int tel;
    private String adresse;
    private String email;



public Client()
{
        
}

    public Client(int nci){
        this.setNci(nci);
    }

    public Client(String nomComplet, int tel)
    {
        this.setNomComplet(nomComplet);
        this.setTel(tel);
    }

    public Client(String adresse, String email)
    {
    this.setAdresse(adresse);
    this.setEmail(email);
    }
   
   
    public int getNci(){
        return nci;
    }

    public String getNomComplet(){
        return nomComplet;
    }

    public int getTel(){
        return tel;
    }
    public String getAdresse(){
        return adresse;
    }   
    public String getEmail(){
        return email;
    }

    public void setNci(int nci){
        this.nci=nci;
    }

    public void setNomComplet(String nomComplet){
        this.nomComplet=nomComplet;
    }

    public void setTel(int tel){
        this.tel=tel;
    }

    public void setAdresse(String adresse){
        this.adresse=adresse;
    }

    public void setEmail(String email){
        this.email=email;
    }
   
}
