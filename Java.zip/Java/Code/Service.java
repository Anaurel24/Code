public class Service extends Local {
    private final int TAILLE = 4;
    private Local tableLocal[] = new Local[TAILLE];
    private int tailleReelle;
    private int nombreDeAppartementReel;
    private int nombreDeChambreReel;
    private int nombreDeLocalReel;
    private int nombreDeReservation;
    private Reservation tableReservation[]=new Reservation[TAILLE];
    
    

  Local[] tableauDeLocal = new Local[TAILLE];

 
 Appartement[] tableauDeAppartement = new Appartement[TAILLE];

 
 Chambre[] tableauDeChambre = new Chambre[TAILLE];
 Reservation[] tableauDeReservation = new Reservation[TAILLE];

    


    public void addLocal(Local l )
    {
        if(tailleReelle < TAILLE)
        {
            tableLocal[tailleReelle] = l;
            tailleReelle++;
        }
        else 
        {
            System.out.println("Le tableau est plein");
        }

    }

    public Chambre searchChambre(String dimension)
    {
        for (Chambre chambre : tableauDeChambre) {
            if (chambre != null) {
                if (chambre.getDimension() == dimension) {
                    return chambre;
                }
            }
        }
        return null;
    }

    public void createChambre(Chambre chambre)
    {
        if (nombreDeChambreReel < TAILLE) {
            tableauDeChambre[nombreDeChambreReel] = chambre;
            nombreDeChambreReel++;
        } else {
            System.out.println("Table de chambre plein  :( ");
        }
    }

    public Appartement searchAppartement(String reference)
    {
        for (Appartement appartement : tableauDeAppartement) {
            if (appartement != null) {
                if (appartement.getReference().compareTo(reference) == 0) {
                    return appartement;
                }
            }
        }
        return null;
    }
    public void createAppartement(Appartement appartement)
    {
        if (nombreDeAppartementReel < TAILLE) {
            tableauDeAppartement[nombreDeAppartementReel] = appartement;
            nombreDeAppartementReel++;
        } else {
            System.out.println("Table de appartement plein  :( ");
        }
    }

    public void createLocal(Local local)
    {
        
            if (nombreDeLocalReel < TAILLE) {
                tableauDeLocal[nombreDeLocalReel] = local;
                nombreDeLocalReel++;
            } else {
                System.out.println("Table de local plein  :( ");
            }    
    }

    public Local searchLocal(String type)
    {
        for (Local local : tableauDeLocal) {
            if ( local!= null) {
                if (local.getType().compareTo(type) == 0) {
                    return local;
                }
            }
        }
        return null;   
    }
    public void addReservation(Reservation reservation){
        if(tailleReelle < TAILLE)
        {
            tableReservation[tailleReelle] = reservation;
            tailleReelle++;
        }

    }
     public void createReservation(Reservation reservation)
    {
        if (nombreDeReservation < TAILLE) {
            tableauDeReservation[nombreDeReservation] = reservation;
            nombreDeReservation++;
        } else {
            System.out.println("Table de Reservation :( ");
        }
    }
    

    

}
