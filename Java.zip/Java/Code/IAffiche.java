public interface IAffiche {
  
    public String afficher();

}
