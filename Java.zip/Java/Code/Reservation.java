import java.time.LocalDate;

public abstract class Reservation implements IAffiche
{
    private String referenceLoc;
    private int nci;
    public LocalDate date;
    private int id;


    public Reservation(){

    }
    
    public Reservation(String referenceLoc,int nci){
        //this.setNci(nci);
        this.setReferenceLoc(referenceLoc);
        this.setNci(nci);
    }
    public Reservation(int nci ,String reference,int id){
        this.setNci(nci);
        this.setReferenceLoc(referenceLoc);
        this.setId(id);
    }

    
    public String getReferenceLoc(){
        return referenceLoc;
    }
    public int getNci(){
        return nci;
    }
    public LocalDate getDate(){
        return date;
    }
    public int getId(){
        return id;
    }

    public void setReferenceLoc(String referenceLoc){
        this.referenceLoc=referenceLoc;
    }
    public void setNci(int nci){
        this.nci=nci;
    }
    public void setDate(LocalDate date){
        this.date=date;
    }
    public void setId(int id){
        this.id=id;
    }








    
    
}
