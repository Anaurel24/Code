public class Chambre extends Local{

    private String dimension;

    public Chambre(){


    }

    public Chambre(String dimension){
        this.setDimension(dimension);
    }

    public void setDimension(String dimension){
        this.dimension = dimension;
    }

    public String getDimension(){
        return dimension;
    }
@Override
public String afficher()
    {
        return super.afficher() 
        + "\n Dimension : " + getDimension();
    } 
}