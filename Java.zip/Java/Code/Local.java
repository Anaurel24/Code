public abstract class Local implements IAffiche {
    private   int nombreLocal;
    private String reference;
    private final int FORMAT = 4;
    protected String localisation;
    protected int prix;
    protected int prix2;
    protected int prix3;
    protected int tauxloc;
    protected String type;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    public int getPrix() {
        return prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    public int getPrix2() {
        return prix2;
    }

    public void setPrix2(int prix2) {
        this.prix2 = prix2;
    }

    public int getPrix3() {
        return prix3;
    }

    public void setPrix3(int prix3) {
        this.prix3 = prix3;
    }

    public int getTauxloc() {
        return tauxloc;
    }

    public void setTauxloc(int tauxloc) {
        this.tauxloc = tauxloc;
    }

    public String getReference(){
        return reference;
    }

    public void setReference(String reference){
        this.reference=reference;
    }

    static Appartement appartement = new Appartement();
 
    public Appartement getAppartement() {
        return appartement;
    }

    static Chambre chambre = new Chambre();
 
    public Chambre getChambre() {
        return chambre;
    }

    public String getLocalisation(){
        return localisation;
    }

    public void setLocalisation( String localisation ){
        this.localisation = localisation; 
    }

    public void setAppartement(Appartement appartement) {
        this.appartement = appartement;
        appartement.addLocal(this);
    }

    public void setChambre(Chambre chambre) {
        this.chambre = chambre;
    }

    public Local(){
        reference = generateReference();
    }

    public Local(String localisation){
        this.setLocalisation(localisation);
        reference = generateReference();

    }


    private String generateReference()
    {
        String nombreZero = "";
        String nombreDeLocalString = String.valueOf(++nombreLocal);
        for(int i=1; i<=(FORMAT - nombreDeLocalString.length()); i++)
        {
            nombreZero += "0";
        }
        return nombreZero + nombreDeLocalString;
    }
@Override
    public String afficher()
    {
        return  "\n reference : " + getReference()
                +"\n Localisation : " + getLocalisation() 
                + "\n type : " + getType()
                + "\n prix : " + getPrix()
                + "\n tauxloc : " + getTauxloc();
                
    }

}

    