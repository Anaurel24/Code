public class Appartement extends Local{
    private int nbrePiece;


    


    public Appartement(){


    }

    public Appartement(int nbrePiece){
        this.setNbrePiece(nbrePiece);
    }

    public Appartement(String localisation, String reference){
        super(localisation);
        this.setReference(reference);
    
    }

// Attribut navigationnel 
private Local[] tableLocal = new Local[5];


public int getNbrePiece() {
    return nbrePiece;
}

public void setNbrePiece(int nbrePiece){
    this.nbrePiece=nbrePiece;
}

private int nombreDeLocal;

public int getNombreDeLocal()
{
    return nombreDeLocal;
}


public Local[] getTableLocal() {
    return tableLocal;
}

public void addLocal( Local local) {
    tableLocal[nombreDeLocal] = local;
    nombreDeLocal++;



}
@Override
public String afficher()
    {
        return super.afficher() 
        + "\n nombre de Piece : " + getNbrePiece();
    }





}

