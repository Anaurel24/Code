//import java.lang.ref.Reference;
import java.lang.ref.Reference;
import java.util.Scanner ;
//import java.io.*;
//import org.json.simple.JSONObject;
//import org.json.simple.parser.JSONParser;
//import org.json.simple.parser.ParseException;

//import jdk.vm.ci.meta.Local;
public class Main 
{ 
    public static Scanner scanner = new Scanner(System.in);

     public static void main(String args[])
    {
         Service service = new Service();
    int choix;
        do{
            choix = menu();
            switch (choix) {
                case 1:
                System.out.print("Entrer la localisation : ");
                String localisation = scanner.nextLine(); //Créer un champ
                Appartement appartement = service.searchAppartement(localisation);
                if (appartement == null)
                {
                    System.out.print("Entrer le taux local  : ");
                    String tauxloc = scanner.nextLine();
                     appartement = new Appartement(localisation,tauxloc);
                    service.createAppartement(appartement);

                }
                
                String typeLocal ;
                int typeLocalInt ;
                do{
                    System.out.println("Quel type de local tu veux : "
                            + "\n 1- Appartement" 
                            + "\n 2- Chambre");
                    typeLocal = scanner.nextLine();
                    typeLocalInt = Integer.parseInt(typeLocal);

                } while (typeLocalInt != 2 && typeLocalInt != 1);
                Local local;
                if(typeLocalInt == 1 )
                {
                    System.out.print("Entrer le nombre de piece : ");
                    String nbrePiece = scanner.nextLine();
                    local = new Appartement(Integer.parseInt(nbrePiece));
                    

                    System.out.print("Entrer prix 1 : ");
                    String prix = scanner.nextLine();

                    System.out.print("Entrer prix 2 : ");
                    String prix2 = scanner.nextLine();

                    System.out.print("Entrer prix 3 : ");
                    String prix3 = scanner.nextLine();


                }else
                {
                    System.out.print("Entrer les dimensions : ");
                    String dimension = scanner.nextLine();
                    local = new Chambre(dimension);
        
                }
                 

               //Affectation du client à un local
                local.setAppartement(appartement);
                service.createAppartement(appartement);
                System.out.print("Le local a ete ajoute et sa reference est : " + appartement.getReference() + "\n"); 
               
                
                    break; 
                case 2:
                String typeLoc;
                int typeLocInt;
                System.out.println("Quel type de local veux-tu afficher : "
                        + "\n 1- Appartement" 
                        + "\n 2- Chambre");
                        typeLoc = scanner.nextLine();
                        typeLocInt = Integer.parseInt(typeLoc);
                    Local lc;
                    if(typeLocInt == 1){

                        System.out.print("Entrer la référence de l'appartement : ");
                        String refLocal = scanner.nextLine();
                       
                        lc = service.searchLocal(refLocal);
                        if(lc != null){
                            System.out.print("Données du local : ");
                            System.out.println(lc.afficher());
                        }else{
                            System.out.print("Erreur de référence");
                        }                       
                    }else{
                        System.out.print("Entrer la référence de la chambre : ");
                        String refLocal = scanner.nextLine();
                       
                        lc = service.searchLocal(refLocal);
                        if(lc != null){
                            System.out.print("Données du local : ");
                            System.out.println(lc.afficher());
                        }else{
                            System.out.print("Erreur de référence" + "\n");
                        }
                    }         
       

               
                    
                break;
                    
                case 3:
                System.out.println("Lister les locaux reserves par un client");
                    break;

                case 4:
                System.out.print("Entrer la reference du local : ");
                String reference = scanner.nextLine();

                //Recherche du compte à partir de son numero
                Appartement ap = service.searchAppartement(reference);
                if(ap != null)
                {

                    System.out.print("Detail du local : ");
                    System.out.println(ap.afficher());
                    System.out.println(ap.getAppartement().afficher());
                    System.out.println(ap.getChambre().afficher());


                    
                }
                else
                {
                    System.out.print("Erreur de reference" + "\n");
  
                }
                break;
            
                case 5:
                //System.out.println("Faire une Reservation");
                System.out.println("Entrer reference du local a réservé");
                String referenceLoc= scanner.nextLine(); 
                System.out.println("Entrer nci du client");
                String nci=scanner.nextLine();
                reservation = new Reservation(referenceLoc,(Integer.parseInt(nci)));
                service.createReservation(reservation);
                //local.setAppartement(appartement);
                //service.createAppartement(appartement);
                System.out.print("Le local a ete reservé"); 
                //Appartement appartement = service.searchAppartement(localisation);

                    break;
                case 6:
                System.out.println("Annuler une Reservation");
                    break;
                case 7:
                System.out.println("Lister les locaux disponibles");
                break;
                case 8:
            System.out.println("Quitter");
                break;
                default:
                    break;
            }

        }while (choix !=8);

    }
    public static int menu()
    {
        int choix;
        System.out.println
        ("Menu"
        + "\n 1-Ajouter un local"  
        + "\n 2-Lister les locaux par type"
        + "\n 3-Lister les locaux reserves par un client"
        + "\n 4-Voir les details d'un local "
        + "\n 5-Faire une Reversation"
        + "\n 6-Annuler une Reservation"
        + "\n 7-Lister les locaux disponibles"
                + "\n 8-Quitter");
        System.out.print("Faites votre choix : ");
        choix = Integer.parseInt(scanner.nextLine());
        return choix;

    }
    //JSONParser jsonP = new JSONParser();
      
         //JSONObject jsonO = (JSONObject)jsonP.parse(new FileReader("C:/locaux.json"));
     
         //String reference = (String) jsonO.get("reference");
         //String localisation = (String) jsonO.get("localisation");
         //int prix = (String) jsonO.get("prix");
         //int tauxLoc= (String) jsonO.get("tauxLoc");
         //System.out.println("reference :"+ reference);
         //System.out.println("localisation: "+ localisation);
         //System.out.println("prix: "+ prix);
         //System.out.println("tauxLoc: "+ tauxLoc);'"
       //catch (FileNotFoundException e) {
        // e.printStackTrace();
      //} catch (IOException e) {
         //e.printStackTrace();
      //} catch (ParseException e) {
         //e.printStackTrace();
      //}
   //}
}

